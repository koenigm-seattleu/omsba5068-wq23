# Heading
NORTH = "North"
EAST  = "East"
SOUTH = "South"
WEST = "West"

