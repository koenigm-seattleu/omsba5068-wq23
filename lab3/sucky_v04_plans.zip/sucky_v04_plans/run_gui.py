from  vacuumenvironmentguisimulator import run
run()
