#####################################################################
#  This is the destination for your shortest_path code.
#  Take all the cells from your notebook vacuum.ipynb and copy the code
#  into this file.
#
#  Now go to work on your go home agent, in gohomeagent.py
#  Notice that the agent code already imports this function

# Delete this line before copying your code in
def shortest_path(source_square, dest_square, free_square_list):
	return []
	